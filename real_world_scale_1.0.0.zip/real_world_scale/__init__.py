# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Real World Scale",
    "author" : "Afshin Mosharaf", 
    "description" : "A shader node group with one value to use as a scale for texture mapping to have textures with same scale acroos different objects",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 0),
    "location" : "ShaderNodeTree_Add node",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Material" 
}


import bpy
import bpy.utils.previews
from .easybpy import *
import os


addon_keymaps = {}
_icons = None


def sna_add_to_node_mt_add_F9901(self, context):
    if not ((bpy.context.area.ui_type != 'ShaderNodeTree')):
        layout = self.layout
        layout.menu('SNA_MT_4F1D8', text='Real World Scale', icon_value=0)


class SNA_MT_4F1D8(bpy.types.Menu):
    bl_idname = "SNA_MT_4F1D8"
    bl_label = "rrr"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.operator_9cff9', text='Add Scale Node', icon_value=0, emboss=True, depress=False)
        op = layout.operator('sna.operator001_3e56b', text='Re-evaluate Scale', icon_value=692, emboss=True, depress=False)


class SNA_OT_Operator_9Cff9(bpy.types.Operator):
    bl_idname = "sna.operator_9cff9"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        active_material = bpy.context.material.name
        import bmesh
        import math
        mat = active_material
        obj_list = []
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                if len(obj.data.materials) > 0:
                    for material in obj.data.materials:
                        if type(material) == type(bpy.data.materials[active_material]):
                            if material.name == mat:
                                obj_list.append(obj)
        for obj in obj_list:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            faces = bm.faces
            area = sum(f.calc_area() for f in faces)

            def segments(p):
                return zip(p, p[1:] + [p[0]])

            def polygon_area(p):
                return 0.5 * abs(sum(x0*y1 - x1*y0 for ((x0, y0), (x1, y1)) in segments(p)))

            def UV_faces_area(_faces, uv_layer):
                return sum([polygon_area([loop[uv_layer].uv for loop in face.loops]) for face in _faces])
            uv_layer = bm.loops.layers.uv.active
            Coverage = 1
            scale = 1
            if uv_layer:
                Coverage  = UV_faces_area(faces , uv_layer)
                scale = math.sqrt((area/24)/(Coverage/.375))
            obj.data['Real World Scale'] = scale
            bm.free()
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'NodeGroups.blend') + r'\NodeTree', filename='Real World Map Size', link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_9D805 = None if not new_data else new_data[0]
        bpy.ops.node.add_node('INVOKE_DEFAULT', type='ShaderNodeGroup', use_transform=True)
        bpy.context.active_node.node_tree = appended_9D805
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Operator001_3E56B(bpy.types.Operator):
    bl_idname = "sna.operator001_3e56b"
    bl_label = "Operator.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        active_material = bpy.context.material.name
        import bmesh
        import math
        mat = active_material
        obj_list = []
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                if len(obj.data.materials) > 0:
                    for material in obj.data.materials:
                        if type(material) == type(bpy.data.materials[active_material]):
                            if material.name == mat:
                                obj_list.append(obj)
        for obj in obj_list:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            faces = bm.faces
            area = sum(f.calc_area() for f in faces)

            def segments(p):
                return zip(p, p[1:] + [p[0]])

            def polygon_area(p):
                return 0.5 * abs(sum(x0*y1 - x1*y0 for ((x0, y0), (x1, y1)) in segments(p)))

            def UV_faces_area(_faces, uv_layer):
                return sum([polygon_area([loop[uv_layer].uv for loop in face.loops]) for face in _faces])
            uv_layer = bm.loops.layers.uv.active
            Coverage = 1
            scale = 1
            if uv_layer:
                Coverage  = UV_faces_area(faces , uv_layer)
                scale = math.sqrt((area/24)/(Coverage/.375))
            obj.data['Real World Scale'] = scale
            bm.free()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.NODE_MT_add.append(sna_add_to_node_mt_add_F9901)
    bpy.utils.register_class(SNA_MT_4F1D8)
    bpy.utils.register_class(SNA_OT_Operator_9Cff9)
    bpy.utils.register_class(SNA_OT_Operator001_3E56B)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.types.NODE_MT_add.remove(sna_add_to_node_mt_add_F9901)
    bpy.utils.unregister_class(SNA_MT_4F1D8)
    bpy.utils.unregister_class(SNA_OT_Operator_9Cff9)
    bpy.utils.unregister_class(SNA_OT_Operator001_3E56B)
